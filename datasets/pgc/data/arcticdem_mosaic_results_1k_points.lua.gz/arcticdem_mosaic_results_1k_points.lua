return {
  [1] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [2] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [3] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.9296875,
      ["band"] = "",
    },
  },
  [4] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [5] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 93.2421875,
      ["band"] = "",
    },
  },
  [6] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.9140625,
      ["band"] = "",
    },
  },
  [7] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [8] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6484375,
      ["band"] = "",
    },
  },
  [9] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.90625,
      ["band"] = "",
    },
  },
  [10] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.3671875,
      ["band"] = "",
    },
  },
  [11] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.6875,
      ["band"] = "",
    },
  },
  [12] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [13] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 51.1796875,
      ["band"] = "",
    },
  },
  [14] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [15] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.578125,
      ["band"] = "",
    },
  },
  [16] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.78125,
      ["band"] = "",
    },
  },
  [17] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [18] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.4921875,
      ["band"] = "",
    },
  },
  [19] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 58.90625,
      ["band"] = "",
    },
  },
  [20] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 46.4375,
      ["band"] = "",
    },
  },
  [21] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [22] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.4296875,
      ["band"] = "",
    },
  },
  [23] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.328125,
      ["band"] = "",
    },
  },
  [24] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.1796875,
      ["band"] = "",
    },
  },
  [25] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [26] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [27] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 72.25,
      ["band"] = "",
    },
  },
  [28] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [29] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.6015625,
      ["band"] = "",
    },
  },
  [30] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [31] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4765625,
      ["band"] = "",
    },
  },
  [32] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [33] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4140625,
      ["band"] = "",
    },
  },
  [34] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.1796875,
      ["band"] = "",
    },
  },
  [35] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [36] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [37] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [38] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 40.96875,
      ["band"] = "",
    },
  },
  [39] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.3984375,
      ["band"] = "",
    },
  },
  [40] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [41] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4140625,
      ["band"] = "",
    },
  },
  [42] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.3515625,
      ["band"] = "",
    },
  },
  [43] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [44] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.765625,
      ["band"] = "",
    },
  },
  [45] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6640625,
      ["band"] = "",
    },
  },
  [46] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [47] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.4375,
      ["band"] = "",
    },
  },
  [48] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.40625,
      ["band"] = "",
    },
  },
  [49] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [50] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.6484375,
      ["band"] = "",
    },
  },
  [51] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 101.453125,
      ["band"] = "",
    },
  },
  [52] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.265625,
      ["band"] = "",
    },
  },
  [53] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [54] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.8515625,
      ["band"] = "",
    },
  },
  [55] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [56] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 50.34375,
      ["band"] = "",
    },
  },
  [57] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [58] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 85.4453125,
      ["band"] = "",
    },
  },
  [59] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [60] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.1953125,
      ["band"] = "",
    },
  },
  [61] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 49.7109375,
      ["band"] = "",
    },
  },
  [62] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4765625,
      ["band"] = "",
    },
  },
  [63] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.3125,
      ["band"] = "",
    },
  },
  [64] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.2421875,
      ["band"] = "",
    },
  },
  [65] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.421875,
      ["band"] = "",
    },
  },
  [66] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 56.71875,
      ["band"] = "",
    },
  },
  [67] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.7109375,
      ["band"] = "",
    },
  },
  [68] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.890625,
      ["band"] = "",
    },
  },
  [69] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [70] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.921875,
      ["band"] = "",
    },
  },
  [71] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [72] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.140625,
      ["band"] = "",
    },
  },
  [73] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.59375,
      ["band"] = "",
    },
  },
  [74] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 44.0859375,
      ["band"] = "",
    },
  },
  [75] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 55.4609375,
      ["band"] = "",
    },
  },
  [76] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [77] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [78] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -0.609375,
      ["band"] = "",
    },
  },
  [79] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [80] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.2421875,
      ["band"] = "",
    },
  },
  [81] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.984375,
      ["band"] = "",
    },
  },
  [82] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 95.484375,
      ["band"] = "",
    },
  },
  [83] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.8125,
      ["band"] = "",
    },
  },
  [84] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [85] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.9609375,
      ["band"] = "",
    },
  },
  [86] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.71875,
      ["band"] = "",
    },
  },
  [87] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.90625,
      ["band"] = "",
    },
  },
  [88] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8046875,
      ["band"] = "",
    },
  },
  [89] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.1015625,
      ["band"] = "",
    },
  },
  [90] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.6171875,
      ["band"] = "",
    },
  },
  [91] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [92] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.609375,
      ["band"] = "",
    },
  },
  [93] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.734375,
      ["band"] = "",
    },
  },
  [94] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [95] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [96] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [97] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.71875,
      ["band"] = "",
    },
  },
  [98] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.6796875,
      ["band"] = "",
    },
  },
  [99] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [100] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [101] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [102] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.703125,
      ["band"] = "",
    },
  },
  [103] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [104] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.03125,
      ["band"] = "",
    },
  },
  [105] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [106] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [107] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [108] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.28125,
      ["band"] = "",
    },
  },
  [109] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.0625,
      ["band"] = "",
    },
  },
  [110] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [111] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [112] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 21.546875,
      ["band"] = "",
    },
  },
  [113] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [114] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5390625,
      ["band"] = "",
    },
  },
  [115] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.4765625,
      ["band"] = "",
    },
  },
  [116] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [117] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [118] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.3203125,
      ["band"] = "",
    },
  },
  [119] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.7578125,
      ["band"] = "",
    },
  },
  [120] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [121] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.921875,
      ["band"] = "",
    },
  },
  [122] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 106.96875,
      ["band"] = "",
    },
  },
  [123] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [124] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6796875,
      ["band"] = "",
    },
  },
  [125] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 44.4453125,
      ["band"] = "",
    },
  },
  [126] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.328125,
      ["band"] = "",
    },
  },
  [127] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.2109375,
      ["band"] = "",
    },
  },
  [128] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.671875,
      ["band"] = "",
    },
  },
  [129] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.953125,
      ["band"] = "",
    },
  },
  [130] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.421875,
      ["band"] = "",
    },
  },
  [131] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [132] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.3203125,
      ["band"] = "",
    },
  },
  [133] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.75,
      ["band"] = "",
    },
  },
  [134] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.03125,
      ["band"] = "",
    },
  },
  [135] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [136] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.90625,
      ["band"] = "",
    },
  },
  [137] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 58.4609375,
      ["band"] = "",
    },
  },
  [138] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [139] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [140] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4921875,
      ["band"] = "",
    },
  },
  [141] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.5546875,
      ["band"] = "",
    },
  },
  [142] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.0703125,
      ["band"] = "",
    },
  },
  [143] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [144] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.9765625,
      ["band"] = "",
    },
  },
  [145] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [146] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.6328125,
      ["band"] = "",
    },
  },
  [147] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [148] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [149] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [150] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [151] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.4296875,
      ["band"] = "",
    },
  },
  [152] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.875,
      ["band"] = "",
    },
  },
  [153] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [154] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [155] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.609375,
      ["band"] = "",
    },
  },
  [156] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 61.875,
      ["band"] = "",
    },
  },
  [157] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 42.9609375,
      ["band"] = "",
    },
  },
  [158] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [159] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [160] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.0078125,
      ["band"] = "",
    },
  },
  [161] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 101.0078125,
      ["band"] = "",
    },
  },
  [162] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [163] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.09375,
      ["band"] = "",
    },
  },
  [164] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [165] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [166] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [167] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [168] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [169] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 55.484375,
      ["band"] = "",
    },
  },
  [170] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [171] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.78125,
      ["band"] = "",
    },
  },
  [172] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [173] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7734375,
      ["band"] = "",
    },
  },
  [174] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.140625,
      ["band"] = "",
    },
  },
  [175] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 103.421875,
      ["band"] = "",
    },
  },
  [176] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [177] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.890625,
      ["band"] = "",
    },
  },
  [178] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.671875,
      ["band"] = "",
    },
  },
  [179] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.390625,
      ["band"] = "",
    },
  },
  [180] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [181] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.90625,
      ["band"] = "",
    },
  },
  [182] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.1484375,
      ["band"] = "",
    },
  },
  [183] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.9296875,
      ["band"] = "",
    },
  },
  [184] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 102.484375,
      ["band"] = "",
    },
  },
  [185] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [186] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [187] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.5859375,
      ["band"] = "",
    },
  },
  [188] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.5234375,
      ["band"] = "",
    },
  },
  [189] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [190] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4296875,
      ["band"] = "",
    },
  },
  [191] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.7421875,
      ["band"] = "",
    },
  },
  [192] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 70.84375,
      ["band"] = "",
    },
  },
  [193] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.0078125,
      ["band"] = "",
    },
  },
  [194] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [195] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.0234375,
      ["band"] = "",
    },
  },
  [196] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.0390625,
      ["band"] = "",
    },
  },
  [197] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.015625,
      ["band"] = "",
    },
  },
  [198] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.9609375,
      ["band"] = "",
    },
  },
  [199] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.6953125,
      ["band"] = "",
    },
  },
  [200] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6484375,
      ["band"] = "",
    },
  },
  [201] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [202] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [203] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [204] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.328125,
      ["band"] = "",
    },
  },
  [205] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [206] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [207] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.203125,
      ["band"] = "",
    },
  },
  [208] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.859375,
      ["band"] = "",
    },
  },
  [209] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [210] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [211] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [212] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [213] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.8125,
      ["band"] = "",
    },
  },
  [214] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [215] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.7109375,
      ["band"] = "",
    },
  },
  [216] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [217] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.75,
      ["band"] = "",
    },
  },
  [218] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.3828125,
      ["band"] = "",
    },
  },
  [219] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 27.625,
      ["band"] = "",
    },
  },
  [220] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [221] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.484375,
      ["band"] = "",
    },
  },
  [222] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.7890625,
      ["band"] = "",
    },
  },
  [223] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [224] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [225] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.078125,
      ["band"] = "",
    },
  },
  [226] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.0234375,
      ["band"] = "",
    },
  },
  [227] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.8671875,
      ["band"] = "",
    },
  },
  [228] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [229] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [230] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 58.265625,
      ["band"] = "",
    },
  },
  [231] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.421875,
      ["band"] = "",
    },
  },
  [232] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.4765625,
      ["band"] = "",
    },
  },
  [233] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [234] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [235] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.8359375,
      ["band"] = "",
    },
  },
  [236] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [237] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.828125,
      ["band"] = "",
    },
  },
  [238] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [239] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [240] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [241] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [242] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.1484375,
      ["band"] = "",
    },
  },
  [243] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [244] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [245] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [246] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [247] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [248] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 27.8125,
      ["band"] = "",
    },
  },
  [249] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.8984375,
      ["band"] = "",
    },
  },
  [250] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.5625,
      ["band"] = "",
    },
  },
  [251] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [252] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8046875,
      ["band"] = "",
    },
  },
  [253] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [254] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.25,
      ["band"] = "",
    },
  },
  [255] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [256] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.4140625,
      ["band"] = "",
    },
  },
  [257] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 63.875,
      ["band"] = "",
    },
  },
  [258] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [259] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.234375,
      ["band"] = "",
    },
  },
  [260] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.3828125,
      ["band"] = "",
    },
  },
  [261] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 56.390625,
      ["band"] = "",
    },
  },
  [262] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.71875,
      ["band"] = "",
    },
  },
  [263] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 18.09375,
      ["band"] = "",
    },
  },
  [264] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.953125,
      ["band"] = "",
    },
  },
  [265] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [266] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.390625,
      ["band"] = "",
    },
  },
  [267] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [268] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.25,
      ["band"] = "",
    },
  },
  [269] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [270] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 50.3203125,
      ["band"] = "",
    },
  },
  [271] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [272] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.6484375,
      ["band"] = "",
    },
  },
  [273] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [274] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.171875,
      ["band"] = "",
    },
  },
  [275] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.859375,
      ["band"] = "",
    },
  },
  [276] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [277] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [278] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6484375,
      ["band"] = "",
    },
  },
  [279] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.4296875,
      ["band"] = "",
    },
  },
  [280] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [281] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.375,
      ["band"] = "",
    },
  },
  [282] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [283] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [284] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 51.296875,
      ["band"] = "",
    },
  },
  [285] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.1640625,
      ["band"] = "",
    },
  },
  [286] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.359375,
      ["band"] = "",
    },
  },
  [287] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.0625,
      ["band"] = "",
    },
  },
  [288] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.6015625,
      ["band"] = "",
    },
  },
  [289] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [290] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [291] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [292] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [293] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.0,
      ["band"] = "",
    },
  },
  [294] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.375,
      ["band"] = "",
    },
  },
  [295] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [296] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [297] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.796875,
      ["band"] = "",
    },
  },
  [298] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.6328125,
      ["band"] = "",
    },
  },
  [299] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.703125,
      ["band"] = "",
    },
  },
  [300] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.3359375,
      ["band"] = "",
    },
  },
  [301] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 45.96875,
      ["band"] = "",
    },
  },
  [302] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.625,
      ["band"] = "",
    },
  },
  [303] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [304] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.453125,
      ["band"] = "",
    },
  },
  [305] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5390625,
      ["band"] = "",
    },
  },
  [306] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 93.3515625,
      ["band"] = "",
    },
  },
  [307] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 43.3515625,
      ["band"] = "",
    },
  },
  [308] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.71875,
      ["band"] = "",
    },
  },
  [309] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [310] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [311] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.2109375,
      ["band"] = "",
    },
  },
  [312] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 27.1171875,
      ["band"] = "",
    },
  },
  [313] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [314] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [315] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.46875,
      ["band"] = "",
    },
  },
  [316] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.5,
      ["band"] = "",
    },
  },
  [317] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [318] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 79.71875,
      ["band"] = "",
    },
  },
  [319] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.375,
      ["band"] = "",
    },
  },
  [320] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.6484375,
      ["band"] = "",
    },
  },
  [321] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [322] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 111.6328125,
      ["band"] = "",
    },
  },
  [323] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.8671875,
      ["band"] = "",
    },
  },
  [324] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [325] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.1484375,
      ["band"] = "",
    },
  },
  [326] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [327] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [328] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.2734375,
      ["band"] = "",
    },
  },
  [329] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.046875,
      ["band"] = "",
    },
  },
  [330] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [331] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.765625,
      ["band"] = "",
    },
  },
  [332] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.453125,
      ["band"] = "",
    },
  },
  [333] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [334] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.9140625,
      ["band"] = "",
    },
  },
  [335] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.2890625,
      ["band"] = "",
    },
  },
  [336] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 104.53125,
      ["band"] = "",
    },
  },
  [337] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [338] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 21.140625,
      ["band"] = "",
    },
  },
  [339] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.890625,
      ["band"] = "",
    },
  },
  [340] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [341] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.2109375,
      ["band"] = "",
    },
  },
  [342] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.2890625,
      ["band"] = "",
    },
  },
  [343] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [344] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.3203125,
      ["band"] = "",
    },
  },
  [345] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.984375,
      ["band"] = "",
    },
  },
  [346] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [347] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [348] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [349] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.53125,
      ["band"] = "",
    },
  },
  [350] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [351] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6953125,
      ["band"] = "",
    },
  },
  [352] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [353] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [354] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.203125,
      ["band"] = "",
    },
  },
  [355] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [356] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 21.2265625,
      ["band"] = "",
    },
  },
  [357] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [358] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.1875,
      ["band"] = "",
    },
  },
  [359] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.328125,
      ["band"] = "",
    },
  },
  [360] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [361] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.6953125,
      ["band"] = "",
    },
  },
  [362] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.4375,
      ["band"] = "",
    },
  },
  [363] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [364] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [365] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.296875,
      ["band"] = "",
    },
  },
  [366] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.75,
      ["band"] = "",
    },
  },
  [367] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [368] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.5390625,
      ["band"] = "",
    },
  },
  [369] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.4140625,
      ["band"] = "",
    },
  },
  [370] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.90625,
      ["band"] = "",
    },
  },
  [371] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.25,
      ["band"] = "",
    },
  },
  [372] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.609375,
      ["band"] = "",
    },
  },
  [373] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [374] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [375] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.328125,
      ["band"] = "",
    },
  },
  [376] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.515625,
      ["band"] = "",
    },
  },
  [377] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [378] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.1171875,
      ["band"] = "",
    },
  },
  [379] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [380] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [381] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [382] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [383] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [384] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [385] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.1875,
      ["band"] = "",
    },
  },
  [386] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8359375,
      ["band"] = "",
    },
  },
  [387] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.4609375,
      ["band"] = "",
    },
  },
  [388] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [389] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.4375,
      ["band"] = "",
    },
  },
  [390] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 92.671875,
      ["band"] = "",
    },
  },
  [391] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.484375,
      ["band"] = "",
    },
  },
  [392] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.6953125,
      ["band"] = "",
    },
  },
  [393] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [394] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 49.375,
      ["band"] = "",
    },
  },
  [395] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.515625,
      ["band"] = "",
    },
  },
  [396] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.703125,
      ["band"] = "",
    },
  },
  [397] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.1328125,
      ["band"] = "",
    },
  },
  [398] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.015625,
      ["band"] = "",
    },
  },
  [399] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.8046875,
      ["band"] = "",
    },
  },
  [400] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [401] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.7734375,
      ["band"] = "",
    },
  },
  [402] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.5234375,
      ["band"] = "",
    },
  },
  [403] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.609375,
      ["band"] = "",
    },
  },
  [404] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.671875,
      ["band"] = "",
    },
  },
  [405] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.0,
      ["band"] = "",
    },
  },
  [406] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4921875,
      ["band"] = "",
    },
  },
  [407] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.484375,
      ["band"] = "",
    },
  },
  [408] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.09375,
      ["band"] = "",
    },
  },
  [409] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.5859375,
      ["band"] = "",
    },
  },
  [410] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.734375,
      ["band"] = "",
    },
  },
  [411] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.484375,
      ["band"] = "",
    },
  },
  [412] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.90625,
      ["band"] = "",
    },
  },
  [413] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [414] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 77.21875,
      ["band"] = "",
    },
  },
  [415] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.765625,
      ["band"] = "",
    },
  },
  [416] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [417] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [418] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.8828125,
      ["band"] = "",
    },
  },
  [419] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.9140625,
      ["band"] = "",
    },
  },
  [420] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [421] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [422] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.203125,
      ["band"] = "",
    },
  },
  [423] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 42.6640625,
      ["band"] = "",
    },
  },
  [424] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.53125,
      ["band"] = "",
    },
  },
  [425] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [426] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.8359375,
      ["band"] = "",
    },
  },
  [427] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.5390625,
      ["band"] = "",
    },
  },
  [428] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.390625,
      ["band"] = "",
    },
  },
  [429] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [430] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [431] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.46875,
      ["band"] = "",
    },
  },
  [432] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 65.25,
      ["band"] = "",
    },
  },
  [433] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.40625,
      ["band"] = "",
    },
  },
  [434] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 95.15625,
      ["band"] = "",
    },
  },
  [435] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [436] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.7421875,
      ["band"] = "",
    },
  },
  [437] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.5859375,
      ["band"] = "",
    },
  },
  [438] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.5625,
      ["band"] = "",
    },
  },
  [439] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [440] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.453125,
      ["band"] = "",
    },
  },
  [441] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.953125,
      ["band"] = "",
    },
  },
  [442] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.4609375,
      ["band"] = "",
    },
  },
  [443] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.515625,
      ["band"] = "",
    },
  },
  [444] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.3984375,
      ["band"] = "",
    },
  },
  [445] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.7890625,
      ["band"] = "",
    },
  },
  [446] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.890625,
      ["band"] = "",
    },
  },
  [447] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.5625,
      ["band"] = "",
    },
  },
  [448] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.9609375,
      ["band"] = "",
    },
  },
  [449] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8046875,
      ["band"] = "",
    },
  },
  [450] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.984375,
      ["band"] = "",
    },
  },
  [451] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [452] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.140625,
      ["band"] = "",
    },
  },
  [453] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.296875,
      ["band"] = "",
    },
  },
  [454] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.71875,
      ["band"] = "",
    },
  },
  [455] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [456] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.1328125,
      ["band"] = "",
    },
  },
  [457] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.4921875,
      ["band"] = "",
    },
  },
  [458] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 82.46875,
      ["band"] = "",
    },
  },
  [459] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.96875,
      ["band"] = "",
    },
  },
  [460] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [461] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.3984375,
      ["band"] = "",
    },
  },
  [462] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.2734375,
      ["band"] = "",
    },
  },
  [463] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.796875,
      ["band"] = "",
    },
  },
  [464] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 56.1171875,
      ["band"] = "",
    },
  },
  [465] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [466] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.265625,
      ["band"] = "",
    },
  },
  [467] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.0546875,
      ["band"] = "",
    },
  },
  [468] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.4140625,
      ["band"] = "",
    },
  },
  [469] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.6015625,
      ["band"] = "",
    },
  },
  [470] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.6796875,
      ["band"] = "",
    },
  },
  [471] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 40.1953125,
      ["band"] = "",
    },
  },
  [472] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [473] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.40625,
      ["band"] = "",
    },
  },
  [474] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.71875,
      ["band"] = "",
    },
  },
  [475] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.90625,
      ["band"] = "",
    },
  },
  [476] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [477] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.84375,
      ["band"] = "",
    },
  },
  [478] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [479] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.84375,
      ["band"] = "",
    },
  },
  [480] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.2578125,
      ["band"] = "",
    },
  },
  [481] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [482] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.015625,
      ["band"] = "",
    },
  },
  [483] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7265625,
      ["band"] = "",
    },
  },
  [484] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.765625,
      ["band"] = "",
    },
  },
  [485] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [486] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [487] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.9140625,
      ["band"] = "",
    },
  },
  [488] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [489] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 87.796875,
      ["band"] = "",
    },
  },
  [490] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [491] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.1875,
      ["band"] = "",
    },
  },
  [492] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.2109375,
      ["band"] = "",
    },
  },
  [493] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [494] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [495] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4921875,
      ["band"] = "",
    },
  },
  [496] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [497] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.1640625,
      ["band"] = "",
    },
  },
  [498] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.8125,
      ["band"] = "",
    },
  },
  [499] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 18.0859375,
      ["band"] = "",
    },
  },
  [500] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [501] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [502] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.765625,
      ["band"] = "",
    },
  },
  [503] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5703125,
      ["band"] = "",
    },
  },
  [504] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [505] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.78125,
      ["band"] = "",
    },
  },
  [506] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [507] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [508] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [509] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [510] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [511] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [512] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.9921875,
      ["band"] = "",
    },
  },
  [513] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [514] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [515] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [516] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.8046875,
      ["band"] = "",
    },
  },
  [517] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.140625,
      ["band"] = "",
    },
  },
  [518] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [519] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [520] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [521] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.0234375,
      ["band"] = "",
    },
  },
  [522] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.59375,
      ["band"] = "",
    },
  },
  [523] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [524] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.703125,
      ["band"] = "",
    },
  },
  [525] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 21.4140625,
      ["band"] = "",
    },
  },
  [526] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [527] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.0703125,
      ["band"] = "",
    },
  },
  [528] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.84375,
      ["band"] = "",
    },
  },
  [529] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [530] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.1875,
      ["band"] = "",
    },
  },
  [531] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [532] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.9296875,
      ["band"] = "",
    },
  },
  [533] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8671875,
      ["band"] = "",
    },
  },
  [534] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.3203125,
      ["band"] = "",
    },
  },
  [535] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.515625,
      ["band"] = "",
    },
  },
  [536] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.6015625,
      ["band"] = "",
    },
  },
  [537] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.609375,
      ["band"] = "",
    },
  },
  [538] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [539] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [540] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [541] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.9453125,
      ["band"] = "",
    },
  },
  [542] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [543] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.7265625,
      ["band"] = "",
    },
  },
  [544] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [545] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [546] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6171875,
      ["band"] = "",
    },
  },
  [547] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [548] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.7109375,
      ["band"] = "",
    },
  },
  [549] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [550] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 82.3828125,
      ["band"] = "",
    },
  },
  [551] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.1640625,
      ["band"] = "",
    },
  },
  [552] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [553] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -0.96875,
      ["band"] = "",
    },
  },
  [554] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.953125,
      ["band"] = "",
    },
  },
  [555] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [556] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.0859375,
      ["band"] = "",
    },
  },
  [557] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.0390625,
      ["band"] = "",
    },
  },
  [558] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.5859375,
      ["band"] = "",
    },
  },
  [559] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4375,
      ["band"] = "",
    },
  },
  [560] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.015625,
      ["band"] = "",
    },
  },
  [561] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.2890625,
      ["band"] = "",
    },
  },
  [562] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [563] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 79.3203125,
      ["band"] = "",
    },
  },
  [564] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.640625,
      ["band"] = "",
    },
  },
  [565] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.78125,
      ["band"] = "",
    },
  },
  [566] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.421875,
      ["band"] = "",
    },
  },
  [567] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [568] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.1953125,
      ["band"] = "",
    },
  },
  [569] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.375,
      ["band"] = "",
    },
  },
  [570] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [571] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.359375,
      ["band"] = "",
    },
  },
  [572] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.515625,
      ["band"] = "",
    },
  },
  [573] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [574] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 85.7421875,
      ["band"] = "",
    },
  },
  [575] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.5546875,
      ["band"] = "",
    },
  },
  [576] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [577] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [578] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [579] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.71875,
      ["band"] = "",
    },
  },
  [580] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [581] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.6953125,
      ["band"] = "",
    },
  },
  [582] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -0.3125,
      ["band"] = "",
    },
  },
  [583] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.9140625,
      ["band"] = "",
    },
  },
  [584] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.9453125,
      ["band"] = "",
    },
  },
  [585] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.375,
      ["band"] = "",
    },
  },
  [586] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [587] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [588] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.125,
      ["band"] = "",
    },
  },
  [589] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.5859375,
      ["band"] = "",
    },
  },
  [590] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 35.0234375,
      ["band"] = "",
    },
  },
  [591] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.9140625,
      ["band"] = "",
    },
  },
  [592] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 86.4375,
      ["band"] = "",
    },
  },
  [593] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [594] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 107.3828125,
      ["band"] = "",
    },
  },
  [595] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.328125,
      ["band"] = "",
    },
  },
  [596] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.796875,
      ["band"] = "",
    },
  },
  [597] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.7578125,
      ["band"] = "",
    },
  },
  [598] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [599] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.15625,
      ["band"] = "",
    },
  },
  [600] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.7421875,
      ["band"] = "",
    },
  },
  [601] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [602] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.890625,
      ["band"] = "",
    },
  },
  [603] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [604] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.6875,
      ["band"] = "",
    },
  },
  [605] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.90625,
      ["band"] = "",
    },
  },
  [606] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [607] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [608] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.296875,
      ["band"] = "",
    },
  },
  [609] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.125,
      ["band"] = "",
    },
  },
  [610] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [611] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [612] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [613] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.390625,
      ["band"] = "",
    },
  },
  [614] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.8359375,
      ["band"] = "",
    },
  },
  [615] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [616] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [617] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.359375,
      ["band"] = "",
    },
  },
  [618] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.71875,
      ["band"] = "",
    },
  },
  [619] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [620] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [621] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.65625,
      ["band"] = "",
    },
  },
  [622] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [623] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6640625,
      ["band"] = "",
    },
  },
  [624] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [625] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [626] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [627] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [628] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.3984375,
      ["band"] = "",
    },
  },
  [629] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [630] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [631] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.0234375,
      ["band"] = "",
    },
  },
  [632] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [633] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.0859375,
      ["band"] = "",
    },
  },
  [634] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6875,
      ["band"] = "",
    },
  },
  [635] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [636] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [637] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [638] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 16.6640625,
      ["band"] = "",
    },
  },
  [639] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.0390625,
      ["band"] = "",
    },
  },
  [640] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [641] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.7109375,
      ["band"] = "",
    },
  },
  [642] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.3671875,
      ["band"] = "",
    },
  },
  [643] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [644] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [645] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [646] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [647] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [648] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.515625,
      ["band"] = "",
    },
  },
  [649] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.203125,
      ["band"] = "",
    },
  },
  [650] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.1875,
      ["band"] = "",
    },
  },
  [651] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.6796875,
      ["band"] = "",
    },
  },
  [652] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [653] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [654] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [655] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5234375,
      ["band"] = "",
    },
  },
  [656] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.3671875,
      ["band"] = "",
    },
  },
  [657] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.96875,
      ["band"] = "",
    },
  },
  [658] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5234375,
      ["band"] = "",
    },
  },
  [659] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.3828125,
      ["band"] = "",
    },
  },
  [660] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [661] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [662] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [663] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 72.28125,
      ["band"] = "",
    },
  },
  [664] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.1015625,
      ["band"] = "",
    },
  },
  [665] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.328125,
      ["band"] = "",
    },
  },
  [666] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6171875,
      ["band"] = "",
    },
  },
  [667] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [668] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [669] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.28125,
      ["band"] = "",
    },
  },
  [670] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [671] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.7890625,
      ["band"] = "",
    },
  },
  [672] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.578125,
      ["band"] = "",
    },
  },
  [673] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.828125,
      ["band"] = "",
    },
  },
  [674] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4296875,
      ["band"] = "",
    },
  },
  [675] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [676] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.015625,
      ["band"] = "",
    },
  },
  [677] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [678] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5859375,
      ["band"] = "",
    },
  },
  [679] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 38.5859375,
      ["band"] = "",
    },
  },
  [680] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [681] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -0.703125,
      ["band"] = "",
    },
  },
  [682] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.296875,
      ["band"] = "",
    },
  },
  [683] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6171875,
      ["band"] = "",
    },
  },
  [684] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5234375,
      ["band"] = "",
    },
  },
  [685] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.640625,
      ["band"] = "",
    },
  },
  [686] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 65.265625,
      ["band"] = "",
    },
  },
  [687] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [688] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [689] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.0859375,
      ["band"] = "",
    },
  },
  [690] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [691] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6640625,
      ["band"] = "",
    },
  },
  [692] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.5234375,
      ["band"] = "",
    },
  },
  [693] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.734375,
      ["band"] = "",
    },
  },
  [694] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [695] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [696] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.78125,
      ["band"] = "",
    },
  },
  [697] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.2578125,
      ["band"] = "",
    },
  },
  [698] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [699] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [700] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.3046875,
      ["band"] = "",
    },
  },
  [701] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.5859375,
      ["band"] = "",
    },
  },
  [702] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 62.9921875,
      ["band"] = "",
    },
  },
  [703] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.765625,
      ["band"] = "",
    },
  },
  [704] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.1796875,
      ["band"] = "",
    },
  },
  [705] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.8984375,
      ["band"] = "",
    },
  },
  [706] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [707] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [708] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.640625,
      ["band"] = "",
    },
  },
  [709] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 85.3671875,
      ["band"] = "",
    },
  },
  [710] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7890625,
      ["band"] = "",
    },
  },
  [711] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.7109375,
      ["band"] = "",
    },
  },
  [712] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.7734375,
      ["band"] = "",
    },
  },
  [713] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 38.1328125,
      ["band"] = "",
    },
  },
  [714] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [715] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 52.9609375,
      ["band"] = "",
    },
  },
  [716] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.9140625,
      ["band"] = "",
    },
  },
  [717] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.4375,
      ["band"] = "",
    },
  },
  [718] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.609375,
      ["band"] = "",
    },
  },
  [719] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [720] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 65.6484375,
      ["band"] = "",
    },
  },
  [721] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [722] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [723] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 23.1953125,
      ["band"] = "",
    },
  },
  [724] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [725] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 50.8125,
      ["band"] = "",
    },
  },
  [726] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [727] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [728] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.2734375,
      ["band"] = "",
    },
  },
  [729] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.046875,
      ["band"] = "",
    },
  },
  [730] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [731] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [732] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [733] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.1015625,
      ["band"] = "",
    },
  },
  [734] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [735] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [736] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.265625,
      ["band"] = "",
    },
  },
  [737] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [738] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 27.21875,
      ["band"] = "",
    },
  },
  [739] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.53125,
      ["band"] = "",
    },
  },
  [740] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7890625,
      ["band"] = "",
    },
  },
  [741] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [742] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 83.484375,
      ["band"] = "",
    },
  },
  [743] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6953125,
      ["band"] = "",
    },
  },
  [744] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 48.203125,
      ["band"] = "",
    },
  },
  [745] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [746] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [747] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7734375,
      ["band"] = "",
    },
  },
  [748] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [749] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.78125,
      ["band"] = "",
    },
  },
  [750] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 61.2890625,
      ["band"] = "",
    },
  },
  [751] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [752] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [753] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [754] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 75.890625,
      ["band"] = "",
    },
  },
  [755] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.859375,
      ["band"] = "",
    },
  },
  [756] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6796875,
      ["band"] = "",
    },
  },
  [757] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 66.953125,
      ["band"] = "",
    },
  },
  [758] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [759] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [760] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 70.1484375,
      ["band"] = "",
    },
  },
  [761] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [762] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6953125,
      ["band"] = "",
    },
  },
  [763] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 40.2109375,
      ["band"] = "",
    },
  },
  [764] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.328125,
      ["band"] = "",
    },
  },
  [765] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 38.796875,
      ["band"] = "",
    },
  },
  [766] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.2109375,
      ["band"] = "",
    },
  },
  [767] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [768] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [769] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [770] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [771] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.828125,
      ["band"] = "",
    },
  },
  [772] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [773] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.7890625,
      ["band"] = "",
    },
  },
  [774] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.7578125,
      ["band"] = "",
    },
  },
  [775] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 64.8125,
      ["band"] = "",
    },
  },
  [776] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [777] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [778] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [779] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7734375,
      ["band"] = "",
    },
  },
  [780] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.6796875,
      ["band"] = "",
    },
  },
  [781] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [782] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [783] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.0078125,
      ["band"] = "",
    },
  },
  [784] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [785] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.6796875,
      ["band"] = "",
    },
  },
  [786] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.0703125,
      ["band"] = "",
    },
  },
  [787] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 13.3125,
      ["band"] = "",
    },
  },
  [788] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.0546875,
      ["band"] = "",
    },
  },
  [789] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 40.46875,
      ["band"] = "",
    },
  },
  [790] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [791] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.75,
      ["band"] = "",
    },
  },
  [792] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7109375,
      ["band"] = "",
    },
  },
  [793] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [794] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6640625,
      ["band"] = "",
    },
  },
  [795] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [796] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5703125,
      ["band"] = "",
    },
  },
  [797] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [798] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.796875,
      ["band"] = "",
    },
  },
  [799] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [800] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 25.875,
      ["band"] = "",
    },
  },
  [801] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7578125,
      ["band"] = "",
    },
  },
  [802] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5078125,
      ["band"] = "",
    },
  },
  [803] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [804] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 98.0859375,
      ["band"] = "",
    },
  },
  [805] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [806] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 89.7109375,
      ["band"] = "",
    },
  },
  [807] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [808] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5234375,
      ["band"] = "",
    },
  },
  [809] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8515625,
      ["band"] = "",
    },
  },
  [810] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.4765625,
      ["band"] = "",
    },
  },
  [811] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 31.4296875,
      ["band"] = "",
    },
  },
  [812] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.625,
      ["band"] = "",
    },
  },
  [813] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -1.4921875,
      ["band"] = "",
    },
  },
  [814] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.734375,
      ["band"] = "",
    },
  },
  [815] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.703125,
      ["band"] = "",
    },
  },
  [816] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 17.984375,
      ["band"] = "",
    },
  },
  [817] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.4453125,
      ["band"] = "",
    },
  },
  [818] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 18.6484375,
      ["band"] = "",
    },
  },
  [819] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.421875,
      ["band"] = "",
    },
  },
  [820] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [821] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.03125,
      ["band"] = "",
    },
  },
  [822] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 34.7734375,
      ["band"] = "",
    },
  },
  [823] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.625,
      ["band"] = "",
    },
  },
  [824] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [825] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.453125,
      ["band"] = "",
    },
  },
  [826] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [827] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 89.625,
      ["band"] = "",
    },
  },
  [828] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.1875,
      ["band"] = "",
    },
  },
  [829] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.2578125,
      ["band"] = "",
    },
  },
  [830] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 71.96875,
      ["band"] = "",
    },
  },
  [831] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [832] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.375,
      ["band"] = "",
    },
  },
  [833] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 20.1171875,
      ["band"] = "",
    },
  },
  [834] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.59375,
      ["band"] = "",
    },
  },
  [835] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [836] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [837] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.578125,
      ["band"] = "",
    },
  },
  [838] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 37.3671875,
      ["band"] = "",
    },
  },
  [839] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 26.921875,
      ["band"] = "",
    },
  },
  [840] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [841] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [842] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 81.046875,
      ["band"] = "",
    },
  },
  [843] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.625,
      ["band"] = "",
    },
  },
  [844] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6875,
      ["band"] = "",
    },
  },
  [845] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [846] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7421875,
      ["band"] = "",
    },
  },
  [847] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.2890625,
      ["band"] = "",
    },
  },
  [848] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [849] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.046875,
      ["band"] = "",
    },
  },
  [850] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [851] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [852] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 40.1875,
      ["band"] = "",
    },
  },
  [853] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 75.5390625,
      ["band"] = "",
    },
  },
  [854] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [855] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [856] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [857] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.75,
      ["band"] = "",
    },
  },
  [858] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.765625,
      ["band"] = "",
    },
  },
  [859] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 38.859375,
      ["band"] = "",
    },
  },
  [860] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.78125,
      ["band"] = "",
    },
  },
  [861] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.671875,
      ["band"] = "",
    },
  },
  [862] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.8984375,
      ["band"] = "",
    },
  },
  [863] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [864] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.65625,
      ["band"] = "",
    },
  },
  [865] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.78125,
      ["band"] = "",
    },
  },
  [866] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.421875,
      ["band"] = "",
    },
  },
  [867] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.4375,
      ["band"] = "",
    },
  },
  [868] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.875,
      ["band"] = "",
    },
  },
  [869] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 45.2421875,
      ["band"] = "",
    },
  },
  [870] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.53125,
      ["band"] = "",
    },
  },
  [871] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [872] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [873] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 6.7109375,
      ["band"] = "",
    },
  },
  [874] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [875] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 18.296875,
      ["band"] = "",
    },
  },
  [876] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 18.6796875,
      ["band"] = "",
    },
  },
  [877] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [878] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.859375,
      ["band"] = "",
    },
  },
  [879] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.328125,
      ["band"] = "",
    },
  },
  [880] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6953125,
      ["band"] = "",
    },
  },
  [881] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.6171875,
      ["band"] = "",
    },
  },
  [882] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.40625,
      ["band"] = "",
    },
  },
  [883] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [884] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.7421875,
      ["band"] = "",
    },
  },
  [885] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.6484375,
      ["band"] = "",
    },
  },
  [886] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.828125,
      ["band"] = "",
    },
  },
  [887] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 11.4375,
      ["band"] = "",
    },
  },
  [888] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 15.4375,
      ["band"] = "",
    },
  },
  [889] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [890] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.0546875,
      ["band"] = "",
    },
  },
  [891] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [892] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.171875,
      ["band"] = "",
    },
  },
  [893] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.1875,
      ["band"] = "",
    },
  },
  [894] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4296875,
      ["band"] = "",
    },
  },
  [895] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [896] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.578125,
      ["band"] = "",
    },
  },
  [897] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 95.734375,
      ["band"] = "",
    },
  },
  [898] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [899] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 4.5703125,
      ["band"] = "",
    },
  },
  [900] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [901] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [902] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [903] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.96875,
      ["band"] = "",
    },
  },
  [904] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.4296875,
      ["band"] = "",
    },
  },
  [905] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5078125,
      ["band"] = "",
    },
  },
  [906] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 27.34375,
      ["band"] = "",
    },
  },
  [907] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [908] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.3828125,
      ["band"] = "",
    },
  },
  [909] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.359375,
      ["band"] = "",
    },
  },
  [910] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.4375,
      ["band"] = "",
    },
  },
  [911] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [912] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 54.9375,
      ["band"] = "",
    },
  },
  [913] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 32.5859375,
      ["band"] = "",
    },
  },
  [914] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 19.703125,
      ["band"] = "",
    },
  },
  [915] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.8203125,
      ["band"] = "",
    },
  },
  [916] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5859375,
      ["band"] = "",
    },
  },
  [917] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 86.7109375,
      ["band"] = "",
    },
  },
  [918] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 30.0234375,
      ["band"] = "",
    },
  },
  [919] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 2.0390625,
      ["band"] = "",
    },
  },
  [920] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [921] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 9.46875,
      ["band"] = "",
    },
  },
  [922] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 85.71875,
      ["band"] = "",
    },
  },
  [923] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [924] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [925] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.546875,
      ["band"] = "",
    },
  },
  [926] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8046875,
      ["band"] = "",
    },
  },
  [927] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.515625,
      ["band"] = "",
    },
  },
  [928] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.34375,
      ["band"] = "",
    },
  },
  [929] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.8046875,
      ["band"] = "",
    },
  },
  [930] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [931] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [932] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5,
      ["band"] = "",
    },
  },
  [933] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.5,
      ["band"] = "",
    },
  },
  [934] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [935] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 87.890625,
      ["band"] = "",
    },
  },
  [936] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [937] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -3.03125,
      ["band"] = "",
    },
  },
  [938] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 89.390625,
      ["band"] = "",
    },
  },
  [939] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [940] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [941] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [942] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 89.953125,
      ["band"] = "",
    },
  },
  [943] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.2421875,
      ["band"] = "",
    },
  },
  [944] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [945] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.3203125,
      ["band"] = "",
    },
  },
  [946] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.5546875,
      ["band"] = "",
    },
  },
  [947] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [948] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 74.40625,
      ["band"] = "",
    },
  },
  [949] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 7.9375,
      ["band"] = "",
    },
  },
  [950] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 29.6953125,
      ["band"] = "",
    },
  },
  [951] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [952] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [953] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 91.234375,
      ["band"] = "",
    },
  },
  [954] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 42.6875,
      ["band"] = "",
    },
  },
  [955] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.453125,
      ["band"] = "",
    },
  },
  [956] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 41.15625,
      ["band"] = "",
    },
  },
  [957] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 77.421875,
      ["band"] = "",
    },
  },
  [958] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 33.75,
      ["band"] = "",
    },
  },
  [959] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.6328125,
      ["band"] = "",
    },
  },
  [960] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.734375,
      ["band"] = "",
    },
  },
  [961] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.5859375,
      ["band"] = "",
    },
  },
  [962] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [963] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 51.1015625,
      ["band"] = "",
    },
  },
  [964] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.6171875,
      ["band"] = "",
    },
  },
  [965] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 3.71875,
      ["band"] = "",
    },
  },
  [966] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.1171875,
      ["band"] = "",
    },
  },
  [967] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 24.078125,
      ["band"] = "",
    },
  },
  [968] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 44.3671875,
      ["band"] = "",
    },
  },
  [969] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 22.2578125,
      ["band"] = "",
    },
  },
  [970] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.7734375,
      ["band"] = "",
    },
  },
  [971] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [972] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [973] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 39.1484375,
      ["band"] = "",
    },
  },
  [974] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.421875,
      ["band"] = "",
    },
  },
  [975] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 53.7734375,
      ["band"] = "",
    },
  },
  [976] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 47.359375,
      ["band"] = "",
    },
  },
  [977] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 12.4140625,
      ["band"] = "",
    },
  },
  [978] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 28.9609375,
      ["band"] = "",
    },
  },
  [979] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -0.0078125,
      ["band"] = "",
    },
  },
  [980] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 14.1328125,
      ["band"] = "",
    },
  },
  [981] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 36.984375,
      ["band"] = "",
    },
  },
  [982] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [983] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [984] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [985] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [986] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [987] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [988] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = -2.8359375,
      ["band"] = "",
    },
  },
  [989] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 10.4375,
      ["band"] = "",
    },
  },
  [990] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [991] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 0.0703125,
      ["band"] = "",
    },
  },
  [992] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 5.453125,
      ["band"] = "",
    },
  },
  [993] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [994] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [995] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [996] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [997] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [998] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = nan,
      ["band"] = "",
    },
  },
  [999] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 8.265625,
      ["band"] = "",
    },
  },
  [1000] = {
    [1] = {
      ["file"] = "/vsis3/sliderule/data/PGC/arcticdem_2m_v4_1_tiles.vrt",
      ["time"] = 1358108640.0,
      ["value"] = 1.7265625,
      ["band"] = "",
    },
  },
}
