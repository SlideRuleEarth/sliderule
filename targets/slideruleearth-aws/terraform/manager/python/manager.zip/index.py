def certbot_handler(event, context):
   return {
       'message' : event['message']
   }
